from flask import Blueprint

progress_bp = Blueprint("progress", __name__, url_prefix="/progress")

from routes import progress as _progress_routes