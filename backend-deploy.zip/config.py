import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'bro-dev-secret-2026'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///instance/bro.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JWT_SECRET_KEY = 'bro-jwt-secret-change-later'